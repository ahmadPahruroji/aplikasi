<?php $__env->startSection('content'); ?>
<div class="page-header">
  <div class="container-fluid">
    <h2 class="h5 no-margin-bottom">Data Koordinator</h2>
  </div>
</div>

<section>
	
<div class="container">
	<div class="row">
		<div class="col-2">
			
		</div>
		<div class="col-8">
			<div class="card">
				<div class="card-header">
					<a href="<?php echo e(url('coordinators')); ?>" type="button" class="btn btn-secondary"><i class="fa fa-arrow-left"> </i> Kembali</a>
					<h5 class="pull-right">Form Edit Koordinator</h5>
				</div>
				<div class="card-body">
					<form action="<?php echo e(route('coordinators.update',$coordinators->id)); ?>" method="post">
						<?php echo method_field('put'); ?>
						<?php echo csrf_field(); ?>

					<div class="form-group">
						
						<label>Nama Warga</label>
							<select class="form-control select2" name="member_id">
								<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($member->id); ?>" <?php echo e($member->id==$coordinators->member_id ? 'selected':null); ?>><?php echo e($member->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
					</div> 
					<div class="form-group">
						<label>Keterangan</label>
						<textarea type="text" class="form-control" name="description" placeholder="type something"><?php echo e($coordinators->member->description); ?></textarea>
					</div> 

					<button type="submit" class="btn btn-success pull-right"><i class="fa fa-check"></i> Submit</button> 
					</form>
		<div class="col-2">
			
		</div>
				</div>
			</div>
		</div>
	</div>
</div>
	
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>