<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Admin Grasud</title>
  <meta name="description" content="Free Bootstrap 4 Admin Theme | Pike Admin">
  <meta name="author" content="Pike Web Development - https://www.pikephp.com">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


  
  <!-- Favicon -->
  <link rel="shortcut icon" href="<?php echo e(asset('Admin/assets/images/favicon.ico')); ?>">

  <!-- Bootstrap CSS -->
  <link href="<?php echo e(asset('Admin/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />

  <!-- Font Awesome CSS -->
  <link href="<?php echo e(asset('Admin/assets/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />

  <!-- Custom CSS -->
  <link href="<?php echo e(asset('Admin/assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />

  <!-- BEGIN CSS for this page -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css"/>
  <!-- END CSS for this page -->
  <link href="<?php echo e(asset('Admin/assets/plugins/datetimepicker/css/daterangepicker.css')); ?>" rel="stylesheet" /> 
  <!-- Switchery css -->
  <link href="<?php echo e(asset('Admin/assets/plugins/switchery/switchery.min.css')); ?>" rel="stylesheet" />
  <!-- Boostrap datepicker -->
  <link href="<?php echo e(asset('Admin/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css')); ?>" rel="stylesheet" />
  <!-- Bootstrap DatePicker css -->
  <link href="<?php echo e(asset('Admin/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('Admin/assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css"/>
  
</head>

<body class="adminbody">

  <div id="main">

   <!-- top bar navigation -->
   <div class="headerbar">

    <!-- LOGO -->
    <div class="headerbar-left">
     <a href="index.html" class="logo"><img alt="Logo" src="<?php echo e(asset('Admin/assets/images/lg.png')); ?>" /> <span>Admin</span></a>
   </div>

   <nav class="navbar-custom">

    <ul class="list-inline float-right mb-0">

      <li class="list-inline-item dropdown notif">
        <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">

        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-arrow-success dropdown-lg">
          <!-- item-->
          <div class="dropdown-item noti-title">

          </div>

          <!-- item-->
          <a target="_blank" href="https://www.pikeadmin.com" class="dropdown-item notify-item">                                    

          </a>

          <!-- item-->
          <a target="_blank" href="https://www.pikeadmin.com/pike-admin-pro" class="dropdown-item notify-item">                                    

          </a>                               

          <!-- All-->
          <a title="Clcik to visit Pike Admin Website" target="_blank" href="https://www.pikeadmin.com" class="dropdown-item notify-item notify-all">

          </a>

        </div>
      </li>

      <li class="list-inline-item dropdown notif">
        <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
          
        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-arrow-success dropdown-lg">
          <!-- item-->
          <div class="dropdown-item noti-title">
            
          </div>

          <!-- item-->
          <a href="#" class="dropdown-item notify-item">                                    
                       
                        </a>

                        <!-- item-->
                        <a href="#" class="dropdown-item notify-item">                                    
                       
                        </a>

                        <!-- item-->
                        <a href="#" class="dropdown-item notify-item">                                    
                       
                        </a>

                        <!-- All-->
                        <a href="#" class="dropdown-item notify-item notify-all">
                         
                       </a>

                     </div>
                   </li>

                   <li class="list-inline-item dropdown notif">
                    <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                      <i class="fa fa-fw fa-bell-o"></i><span class="notif-bullet"></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-lg">
                      <!-- item-->
                      <div class="dropdown-item noti-title">
                       
                     </div>

                     <!-- item-->
                     <a href="#" class="dropdown-item notify-item">
                      <div class="notify-icon bg-faded">
                       
                     </div>
                        
                        </a>

                        <!-- item-->
                        <a href="#" class="dropdown-item notify-item">
                          <div class="notify-icon bg-faded">
                           
                         </div>
                      
                        </a>

                        <!-- item-->
                        <a href="#" class="dropdown-item notify-item">
                          <div class="notify-icon bg-faded">
                           
                     
                        </a>

                        <!-- All-->
                        <a href="#" class="dropdown-item notify-item notify-all">
                          
                        </a>

                      </div>
                    </li>

                    <li class="list-inline-item dropdown notif">
                      <a class="nav-link dropdown-toggle nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                        <img src="<?php echo e(asset('Admin/assets/images/avatars/admin.png')); ?>" alt="Profile image" class="avatar-rounded">
                      </a>
                      <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                        <!-- item-->
                        <div class="dropdown-item noti-title">
                          <h5 class="text-overflow"><small>Hello, admin</small> </h5>
                        </div>

                        <!-- item-->
                        <a href="pro-profile.html" class="dropdown-item notify-item">
                          <i class="fa fa-user"></i> <span>Profile</span>
                        </a>

                        <!-- item-->
                        <a href="#" class="dropdown-item notify-item" onclick="logout()">
                          <i class="fa fa-power-off"></i> <span>Logout</span>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                        </form>

                        <!-- item-->
                        <a target="_blank" href="https://www.pikeadmin.com" class="dropdown-item notify-item">
                         
                       </a>
                     </div>
                   </li>

                 </ul>

                 <ul class="list-inline menu-left mb-0">
                  <li class="float-left">
                    <button class="button-menu-mobile open-left">
                      <i class="fa fa-fw fa-bars"></i>
                    </button>
                  </li>                        
                </ul>

              </nav>

            </div>
            <!-- End Navigation -->


            <!-- Left Sidebar -->
            <div class="left main-sidebar">

              <div class="sidebar-inner leftscroll">

               <div id="sidebar-menu">

                 <ul>
                  
                  <li <?php echo e(Request::is('home') ? 'class=active' : ''); ?>>
                    <a href="<?php echo e(route('home')); ?>" class="active"> <i class="fa fa-fw fa-home"></i><span> Dashboard </span> </a>
                  </li>
                  
                  <li <?php echo e(Request::is('users') ? 'class=active' : ''); ?>>
                    <a href="#userdropdown" aria-expanded="false" data-toggle="collapse"><i class="fa fa-fw fa-address-book"></i> <span> Data Users </span> <span class="menu-arrow"></span></a>
                    <ul id="userdropdown" class="collapse list-unstyled">
                      <li><a href="<?php echo e(url ('users')); ?>"><i class="fa fa-fw fa-user"></i>Users</a></li>
                      <li><a href="<?php echo e(url ('biodatas')); ?>"><i class="fa fa-fw fa-user"></i>Biodata</a></li>
                    </ul>
                  </li>
                  
                  
                  
                  <li <?php echo e(Request::is('members') ? 'class=active' : ''); ?>>
                   <a href="#memberdropdown" aria-expanded="false" data-toggle="collapse"><i class="fa fa-fw fa-users"></i> <span> Data Warga </span> <span class="menu-arrow"></span></a>
                   <ul id="memberdropdown" class="collapse list-unstyled">
                    <li><a href="<?php echo e(url ('members')); ?>"><i class="fa fa-fw fa-user"></i>Warga</a></li>
                    
                    <li><a href="<?php echo e(url ('officers')); ?>"><i class="fa fa-fw fa-user"></i>Petugas</a></li>
                  </ul>
                </li>
                
                <li <?php echo e(Request::is('events') ? 'class=active' : ''); ?>>
                  <a href="<?php echo e(url ('events')); ?>"> <i class="fa fa-fw fa-calendar"></i><span> Kegiatan </span> </a>
                </li>
                
                
                
                <li <?php echo e(Request::is('groups') ? 'class=active' : ''); ?>>
                 <a href="#iurandropdown" aria-expanded="false" data-toggle="collapse"><i class="fa fa-fw fa-money"></i> <span> Data Iuran </span> <span class="menu-arrow"></span></a>
                 <ul id="iurandropdown" class="collapse list-unstyled">
                   <li><a href="<?php echo e(url ('categories')); ?>"><i class="fa fa-fw fa-bookmark"></i>Kategori</a></li>
                   <li><a href="<?php echo e(url ('countributions')); ?>"><i class="fa fa-fw fa-bookmark"></i>Iuran</a></li>
                   <li><a href="<?php echo e(url ('proofs')); ?>"><i class="fa fa-fw fa-bookmark"></i>Data Bukti</a></li>
                   <li><a href="<?php echo e(url ('spendings')); ?>"><i class="fa fa-fw fa-bookmark"></i>Pengeluaran</a></li>
                 </ul>
               </li>
               
               <li <?php echo e(Request::is('complaints') ? 'class=active' : ''); ?>>
                <a href="<?php echo e(url ('complaints')); ?>"> <i class="fa fa-fw fa-comment"></i><span> Keluhan </span> </a>
              </li>
              
              <li <?php echo e(Request::is('contacts') ? 'class=active' : ''); ?>>
                <a href="<?php echo e(url ('contacts')); ?>"> <i class="fa fa-fw fa-phone"></i><span> Kontak </span> </a>
              </li>
        

        

        

    

    

    

    

    </ul>

    

  </div>

  

</div>

</div>
<!-- End Sidebar -->


<div class="content-page">

  <!-- Start content -->
  <div class="content">

    

                       
                                  <!-- end row -->

                        

                      
                                    

                                    

                                    

                                    
                                        
                                        <!-- end row -->



                                        

                                          
                                            
                                            

                                                                      
                                              
                                            
                                            <!-- end card-->                  
                                          

                                          
                                            
                                            

                                           
                                              
                                            
                                            <!-- end card-->                  
                                          

                                          
                                        
                                          <!-- end card-->                  
                                        

                                      
                                      <!-- end row -->


                                      

                                        
                                          
                                            

                                              

                                                
                                                                                                        
                                                    
                                                    

                                                  
                                                
                                                <!-- end card-->                  
                                              


                                              
                                                
                                            

                                              
                                                
                                               
                                                
                                                
                                                
                                                

                                              

                                              
                                               

                                              

                                              
                                                

                                              

                                              
                                                

                                              

                                              
                                                 

                                              

                                              
                                                
                                                
                                                
                                                
                                                                                
                                            
                                            
                                          
                                          <!-- end card-->                  
                                        


                                        
                                          
                                           

                                              

                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                               
                                                                
                                                                
                                                                
                                                                

                                                              
                                                              
                                                            
                                                            <!-- end card-->                  
                                                          

                                                        

                                                        


                                                      
                                                      <!-- END container-fluid -->

                                                    
                                                    <!-- END content -->

                                                  
                                                  <!-- END content-page -->
                                                  <div class="content-inner" id="app">
                                                    <?php echo $__env->yieldContent('content'); ?>
                                                  </div>
                                                  <footer class="footer">
                                                    <span class="text-right">
                                                      Copyright <a target="_blank" href="#">Grasud</a>
                                                    </span>
                                                    <span class="float-right">
                                                      Powered by <a target="_blank" href="#"><b>Admin Grasud</b></a>
                                                    </span>
                                                  </footer>

                                                </div>
                                                <!-- END main -->

                                                <script src="<?php echo e(asset('Admin/assets/js/modernizr.min.js')); ?>"></script>
                                                <script src="<?php echo e(asset('Admin/assets/js/jquery.min.js')); ?>"></script>
                                                <script src="<?php echo e(asset('Admin/assets/js/moment.min.js')); ?>"></script>

                                                <script src="<?php echo e(asset('Admin/assets/js/popper.min.js')); ?>"></script>
                                                <script src="<?php echo e(asset('Admin/assets/js/bootstrap.min.js')); ?>"></script>

                                                <script src="<?php echo e(asset('Admin/assets/js/detect.js')); ?>"></script>
                                                <script src="<?php echo e(asset('Admin/assets/js/fastclick.js')); ?>"></script>
                                                <script src="<?php echo e(asset('Admin/assets/js/jquery.blockUI.js')); ?>"></script>
                                                <script src="<?php echo e(asset('Admin/assets/js/jquery.nicescroll.js')); ?>"></script>
                                                
                                                <script src="<?php echo e(asset('Admin/assets/plugins/datetimepicker/js/moment.min.js')); ?>"></script>
                                                <script src="<?php echo e(asset('Admin/assets/plugins/datetimepicker/js/daterangepicker.js')); ?>"></script>
                                                <!-- App js -->
                                                <script src="<?php echo e(asset('Admin/assets/js/pikeadmin.js')); ?>"></script>

                                                <!-- BEGIN Java Script for this page -->
                                                <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
                                                <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
                                                <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
                                                <!-- sweet -->
                                                <!-- <script src="assets/js/detect.js"></script> -->
                                                <!-- <script src="assets/js/fastclick.js"></script> -->
                                                <!-- <script src="assets/js/jquery.blockUI.js"></script> -->
                                                <!-- <script src="assets/js/jquery.nicescroll.js"></script> -->
                                                <script src="<?php echo e(asset('Admin/assets/js/jquery.scrollTo.min.js')); ?>"></script>
                                                <script src="<?php echo e(asset('Admin/assets/plugins/switchery/switchery.min.js')); ?>"></script>
                                                <!-- Counter-Up-->
                                                <script src="<?php echo e(asset('Admin/assets/plugins/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
                                                <!-- Bootstrap date -->
                                                <script src="<?php echo e(asset('Admin/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js')); ?>"></script>
                                                <!-- Counter-Up-->
                                                <script src="<?php echo e(asset('Admin/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
                                                
                                                <script src="<?php echo e(asset('Admin/assets/plugins/counterup/jquery.counterup.min.js')); ?>"></script>			
                                                <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.26.12/sweetalert2.all.js"></script>
                                                <script src="<?php echo e(asset('Admin/assets/plugins/select2/js/select2.min.js')); ?>"></script>
                                                <script>                
                                                  $(document).ready(function() {
                                                    $('.select2').select2();
                                                  });
                                                </script>
                                                <script>
                                                  $(document).ready(function() {
                                                    $('.date').daterangepicker({
                                                      singleDatePicker: true,
                                                      showDropdowns: true,
                                                      locale: {
                      format: 'MMMM'
                    }
                                                    });
                                                  });
                                                </script>
                                                <script>
                                                  $(document).ready(function() {
			// data-tables
			$('.datatable').DataTable();

			// counter-up
			$('.counter').counterUp({
				delay: 10,
				time: 600
			});
		} );		
	</script>
	
	<script>

    const logout = ()=>{
      swal({
        type:"info",
        title: "Logout from here?",
        confirmButtonText: "<i class='fa fa-thumbs-up'></i> Yes, Log me out",
        showCancelButton:true,
        cancelButtonColor: '#d33',
        cancelButtonText: "<i class='fa fa-close'></i> Cancel"
      }).then(res=>{
        if(res.value){
          $("#logout-form").submit();
        }
      });
    }

  </script>
  <!-- END Java Script for this page -->
  <?php echo $__env->yieldContent('script'); ?>
</body>
</html>