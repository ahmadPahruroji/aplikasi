<?php $__env->startSection('content'); ?>
<div class="page-header">
  <div class="container-fluid">
    
    <div class="alert alert-primary" role="alert">
          <i class="fa fa-call"></i> USER
        </div>
  </div>
</div>

<section>
	
<div class="container">
	<div class="row">
		<div class="col-2">
			
		</div>
		<div class="col-8">
			<div class="card">
				<div class="card-header border-primary">
					<a href="<?php echo e(url('users')); ?>" type="button" class="btn btn-secondary"><i class="fa fa-arrow-left"> </i> Kembali</a>
					<h5 class="pull-right">Form Edit User</h5>
				</div>
				<div class="card-body">
					<form action="<?php echo e(route('users.update',$users->id)); ?>" method="post">
						<?php echo method_field('put'); ?>
						<?php echo csrf_field(); ?>

					<div class="form-group">
						
						<label>Role ID</label>
							<select class="form-control select2" name="role_id">
								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($role->id); ?>" <?php echo e($role->id==$users->role_id ? 'selected':null); ?>><?php echo e($role->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
					</div> 
					<div class="form-group">
						<label>Nama</label>
						<input type="text" class="form-control" value="<?php echo e($users->name); ?>"  name="name" placeholder="type something" required> 
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" class="form-control" value="<?php echo e($users->email); ?>"  name="email" placeholder="type something" required> 
					</div> 
					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" value="<?php echo e($users->password); ?>"  name="password" placeholder="type something" required> 
					</div> 
					<button type="submit" class="btn btn-success pull-right"><i class="fa fa-check"></i> Submit</button> 
		<div class="col-2">
			
		</div>
				</div>
			</div>
		</div>
	</div>
</div>
	
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>