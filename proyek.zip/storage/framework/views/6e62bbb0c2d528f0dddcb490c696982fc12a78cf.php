<?php $__env->startSection('content'); ?>
<div class="page-header">
  <div class="container-fluid">
    
</div>
</div>
<section>

    <div class="container-fluid">
      <div class="card">
            <div class="card-header bg-primary mb-3 text-white" style="color: #6194c1">
                <h3> Data Warga </h3>
            </div>
        <div class="card">
           <div class="card-header border-primary">
              <i class="fa fa-flag"></i> List Warga
              <a href="<?php echo e(route('members.create')); ?>" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Tambah Data</a>
          </div>
          <div class="card-body">
              <div class="table-responsive">
                 <table class="table table-striped datatable">
                    <thead>
                       <tr>
                          <td>No</td>
                          <td>Nama</td>
                          <td>ALAMAT/BLOK</td>
                          <td>Nomor HP</td>
                          <td>KK</td>
                          <td>KETERANGAN</td>
                          <td>Action</td>
                      </tr>
                  </thead>
                  <tbody>

                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($m+1); ?></td>
                        <td><?php echo e($member->name); ?></td>
                        <td><?php echo e($member->alamat); ?></td>
                        <td><?php echo e($member->no_hp); ?></td>
                        <td><?php echo e($member->kk); ?></td>
                        <td><?php echo e($member->description); ?></td>
                        <td>
                         <center>
                            <div class="btn-group">
                                <button type="button" class="btn btn-danger" onclick="destroy(<?php echo e($member->id); ?>)"><i class="fa fa-trash"></i> Hapus</button>
                                <a href="<?php echo e(route('members.edit',$member->id)); ?>" type="button" class="btn btn-warning" ><i class="fa fa-gear"></i> Edit</a>
                            </div>
                        </center> 
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</div>
</div>
</div>
</div>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(()=>{
        console.log("user page");
    });

    const destroy = (id)=>{
        swal({
            title:"Apa Kamu Yakin?",
            text:"Anda tidak akan dapat mengembalikan data ini!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!'
        }).then(result=>{
            if(result.value){
                let access = {
                    id:id,
                    _method:'delete',
                    _token:"<?php echo e(csrf_token()); ?>"
                }
                $.post("<?php echo e(url('members')); ?>/"+id,access)
                .done(res=>{
                    console.log(res);
                    swal({
                        title:"Oke",
                        text:"Anda menghapus Data",
                        type:"success",
                    }).then(result=>{
                        window.location = "<?php echo e(url('members')); ?>";
                    })
                }).fail(err=>{
                    console.log(err);
                }); 
            }
        });
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>