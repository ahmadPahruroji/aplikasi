<?php $__env->startSection('content'); ?>
<div class="page-header">
  <div class="container-fluid">
    
</div>
</div>

<section>

    <div class="container-fluid">
        <div class="card">
            <div class="card-header bg-primary mb-3 text-white" style="color: #6194c1">
                <h3> Data Keluhan </h3>
            </div>
            <div class="card">
                <div class="card-header border-primary">
                    <i class="fa fa-flag"></i> List Keluhan
                    <a href="<?php echo e(route('complaints.create')); ?>" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Tambah</a>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Nama</td>
                                    <td>Gambar</td>
                                    <td>Tanggal</td>
                                    <td>Keluhan</td>
                                    <td>Keterangan</td>
                                    <td>Aksi</td>
                                </tr>
                            </thead>
                            <tbody>
                             <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm => $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td><?php echo e($cm+1); ?></td>
                                 <td><?php echo e($complaint->name); ?></td>
                                 <td>
                                    <img src="<?php echo e(asset('storage/'.$complaint->image)); ?>" class="rounded mx-auto d-block" width="50">
                                </td>
                                <td><?php echo e($complaint->date); ?></td>
                                <td><?php echo e($complaint->complain); ?></td>
                                <td><?php echo e($complaint->description); ?></td>
                                <td>
                                  <button type="button" class="btn btn-danger" onclick="destroy(<?php echo e($complaint->id); ?>)"><i class="fa fa-trash"></i> Hapus</button> 
                              </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>   
          </div>
      </div>
  </div>
</div>

</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(()=>{

    });

    const destroy = (id)=>{
        swal({
            title:"Apakah Anda Yakin?",
            text:"Anda Tidak Akan Dapat Mengembalikan Data Ini!",
            type: 'warning',
            showCancelButton: true,
            cancelButtonText: "Batal",
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Saya Yakin!'
        }).then(result=>{
            if(result.value){
                let access = {
                    id:id,
                    _method:'delete',
                    _token:"<?php echo e(csrf_token()); ?>"
                }
                $.post("complaints/"+id,access)
                .done(res=>{
                    console.log(res);
                    swal({
                        title:"Berhasil",
                        text:"Anda Berhasil menghapus Data",
                        type:"success",
                    }).then(result=>{
                        window.location.reload();
                    })
                }).fail(err=>{
                    console.log(err);
                }); 
            }
        });
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>