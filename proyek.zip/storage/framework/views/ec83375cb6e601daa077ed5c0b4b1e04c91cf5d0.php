<?php $__env->startSection('content'); ?>
<div class="page-header">
  <div class="container-fluid">
    <h2 class="h5 no-margin-bottom">Data Iuran</h2>
  </div>
</div>

<section>
	
<div class="container">
	
	<div class="row">
		<div class="col-2">
			
		</div>
		<div class="col-8">
			<div class="card">
				<div class="card-header">
					<a href="<?php echo e(url('countributions')); ?>" type="button" class="btn btn-secondary"><i class="fa fa-arrow-left"> </i> Kembali</a>
					<h5 class="pull-right">Form Iuran</h5>
				</div>
				<div class="card-body">
					<form action="<?php echo e(route('countributions.store')); ?>" method="post">
					<?php echo e(csrf_field()); ?> 
					<div class="form-group">
						<label>Nama Warga</label>
							<select class="form-control select2" name="member_id">
								<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($member->id); ?>"><?php echo e($member->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
					</div>
					<div class="form-group">
						<label>Bulan</label>
						
						
								
							<input type="text" class="form-control date" name="month" />
 
					</div>
					<div class="form-group">
						<label>Jumlah</label>
						<input type="number" class="form-control" name="total" placeholder="type something" required>
					</div>
					<div class="form-group">
						<label>Metode Pembayaran</label>
							<select class="form-control select2" name="payment_id">
								<?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($payment->id); ?>"><?php echo e($payment->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
					</div>
					<div class="form-group">
						<label>Tanggal</label>
						<input type="date" class="form-control" name="date" placeholder="type something" required>
					</div>
					<div class="form-group">
						<label>Status</label>
							<select class="form-control select2" name="status_id">
								<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
					</div>
					
					<button type="submit" class="btn btn-success pull-right"><i class="fa fa-check"></i> Submit</button>

					</form> 
				</div>
			</div>
		</div>
		<div class="col-2">
		</div>
	</div>
	
</div>
	
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>