<?php $__env->startSection('content'); ?>
<div class="page-header">
  <div class="container-fluid">
    
    <div class="alert alert-primary" role="alert">
          <i class="fa fa-call"></i> USER
        </div>
  </div>
</div>

<section>
	
<div class="container">
	
	<div class="row">
		<div class="col-2">
			
		</div>
		<div class="col-8">
			<div class="card">
				<div class="card-header border-primary">
					<a href="<?php echo e(url('users')); ?>" type="button" class="btn btn-secondary"><i class="fa fa-arrow-left"> </i> Kembali</a>
					<h5 class="pull-right">Form User</h5>
				</div>
				<div class="card-body">
					<form action="<?php echo e(route('users.store')); ?>" method="post">
					<?php echo e(csrf_field()); ?> 
					<div class="form-group">
						<label>Role ID</label>
							<select class="form-control select2" name="role_id">
								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
					</div>
					<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						<label>Nama</label>
						<input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="type something" required> 

						<?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
						<label>Email</label>
						<input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="type something" required>

						<?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?> 
					</div> 
					<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
						<label>Password</label>
						<input id="password" type="password" class="form-control" name="password" placeholder="type something" required> 

						<?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
					</div> 
					<div class="form-group">
						<label>Confirm Password</label>
						<input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
					</div>			
					
					<button type="submit" class="btn btn-success pull-right"><i class="fa fa-check"></i> Submit</button>

					</form> 
				</div>
			</div>
		</div>
		<div class="col-2">
		</div>
	</div>
	
</div>
	
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>