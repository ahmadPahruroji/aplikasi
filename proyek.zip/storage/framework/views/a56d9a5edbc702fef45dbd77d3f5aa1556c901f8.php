<?php $__env->startSection('content'); ?>
<div class="page-header">
  <div class="container-fluid">
    
    <div class="alert alert-primary" role="alert">
          <i class="fa fa-call"></i> WARGA
        </div>
  </div>
</div>

<section>
	
<div class="container">
	
	<div class="row">
		<div class="col-2">
			
		</div>
		<div class="col-8">
			<div class="card">
				<div class="card-header border-primary">
					<a href="<?php echo e(url('members')); ?>" type="button" class="btn btn-secondary"><i class="fa fa-arrow-left"> </i> Kembali</a>
					<h5 class="pull-right">Form Warga</h5>
				</div>
				<div class="card-body">
					<form action="<?php echo e(route('members.store')); ?>" method="post">
					<?php echo e(csrf_field()); ?> 
					<div class="form-group">
						<label>User</label>
							<select class="form-control select2" name="user_id">
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
					</div>
					<div class="form-group">
						<label>Nama Keluarga</label>
						<input type="text" class="form-control" name="name" placeholder="type something" required>
					</div>
					<div class="form-group">
						<label>Alamat</label>
						<textarea type="text" class="form-control" name="alamat" placeholder="type something" > </textarea>
					</div>
					<div class="form-group">
						<label>KK</label>
						<input type="text" class="form-control" name="kk" placeholder="type something" required>
					</div>
					<div class="form-group">
						<label>Nomor HP</label>
						<input type="text" class="form-control" name="no_hp" placeholder="type something" required>
					</div>
					<div class="form-group">
						<label>Keterangan</label>
						<textarea type="text" class="form-control" name="description" placeholder="type something" > </textarea>
					</div>
					
					<button type="submit" class="btn btn-success pull-right"><i class="fa fa-check"></i> Submit</button>

					</form> 
				</div>
			</div>
		</div>
		<div class="col-2">
		</div>
	</div>
	
</div>
	
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>